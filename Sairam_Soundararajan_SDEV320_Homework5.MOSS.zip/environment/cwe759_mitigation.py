import hashlib
import os

users = {} 

# Add user
username = 'Sairam' #username
password = 'voldemort' #password

salt = os.urandom(32) 
key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
users[username] = { # Store salt and key
    'salt': salt,
    'key': key
}

# Verification attempt 1 (incorrect password)
username = 'Sairam'
password = 'yourpantsfellinhighschool'

salt = users[username]['salt'] # Get salt
key = users[username]['key'] # Get correct key
new_key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)

assert key != new_key # Keys and passwords don't match

key_string1 = str(key)
salt_string1 = str(salt)
new_key_string1 = str(new_key)

print("Key: " + key_string1 + " Salt: " + salt_string1 + "New Key: " + new_key_string1)

# Verification attempt 2 (correct password)
username = 'Sairam'
password = 'voldemort'

salt = users[username]['salt']
key = users[username]['key']
new_key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)

assert key == new_key # Keys and Passwords match!

# Adding another user
username = 'Jimmy'
password = 'Bettyquinlin*neutron'

salt = os.urandom(32) # New salt
key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
users[username] = {
    'salt': salt,
    'key': key
}

# Checking the other users password
username = 'Jimmy'
password = 'Bettyquinlin*neutron'

salt = users[username]['salt']
key = users[username]['key']
new_key = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)

assert key == new_key # Keys and passwords match likewise!

key_string2 = str(key)
salt_string2 = str(salt)
new_key_string2 = str(new_key)


print("Key: " + key_string2 + " Salt: " + salt_string2 + "New Key: " + new_key_string2)