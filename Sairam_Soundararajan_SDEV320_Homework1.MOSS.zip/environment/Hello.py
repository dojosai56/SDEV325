import datetime

print("Hello World from AWS Cloud9!")
print("My name is Sairam Soundararajan and I am graduating from UMGC this May")
print("My hobbies are singing, playing piano, composing (many genres), rapping (a little), playing sports, poetry, reading, and biking")
ct = datetime.datetime.now()
print("The current time is:-", ct)