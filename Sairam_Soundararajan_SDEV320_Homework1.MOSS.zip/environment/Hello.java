/**
 * Class Untitled
 */
import java.sql.Timestamp;
import java.util.Date;
 
public class Hello {
	public static void main(String[] args) {
    	System.out.println("Hello World from AWS Cloud9!");
    	System.out.println("My name is Sairam Soundararajan and I am graduating from UMGC this May");
    	System.out.println("My hobbies are singing, playing piano, composing (many genres), rapping (a little), playing sports, poetry, reading, and biking");
    	Date date = new Date();
    	Timestamp ts = new Timestamp(date.getTime());
    	System.out.println("The time is currently: " + ts);
	}
}