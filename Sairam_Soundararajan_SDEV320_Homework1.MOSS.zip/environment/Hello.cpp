#include <iostream>
#include <ctime>

using namespace std;

int main()
{
	std::cout << "Hello World from AWS Cloud9!" << std::endl;
	cout << "My name is Sairam Soundararajan and I am graduating from UMGC this May" << endl;
	cout << "My hobbies are singing, playing piano, composing (many genres), rapping (a little), playing sports, poetry, reading, and biking" << endl;
	time_t now = time(0);
	char* dt = ctime(&now);
	cout << "The local date and time is: " << dt << endl;
}