import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class cwe798_mitigation {
    public static void main(String[] args) {
        register();
    }

    public static void register() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please create username: ");
        String username = scanner.nextLine();
        System.out.println("Please create desired password: ");
        String password = scanner.nextLine();
        try {
            FileWriter fileWriter = new FileWriter("credentials_java.txt", true);
            fileWriter.write(username + " " + password + "\n");
            fileWriter.close();
            if (login()) {
                System.out.println("Welcome!");
            } else {
                System.out.println("Login Unsuccessful");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean login() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter username:");
        String username = scanner.nextLine();
        System.out.println("Please enter password:");
        String password = scanner.nextLine();
        try {
            File file = new File("credentials_java.txt");
            Scanner fileScanner = new Scanner(file);
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] loginInfo = line.split(" ");
                if (username.equals(loginInfo[0]) && password.equals(loginInfo[1])) {
                    System.out.println("Login credentials are valid!");
                    return true;
                }
            }
            System.out.println("Invalid credentials");
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}