#import sys
#from sys import argv
import hashlib
#import os

def main():
    register()

def register():
    username = input("Please create username: ")
    password = input("Please create desired password: ")
    h = hashlib.sha256()
    password = password.encode()
    h.update(password)
    file = open("credentials1.txt", "a")
    password = h.hexdigest()
    #password = password.decode()
    file.write(username)
    file.write(" ")
    file.write(str(password))
    file.write("\n")
    file.close()
    if login():
        print("Welcome!")
    else:
        print("Login Unsuccessful")

def login():
    username = input("Please enter username:")
    password = input("Please enter password:")
    h = hashlib.sha256()
    password = password.encode()
    h.update(password)
    password = h.hexdigest()
    password = str(password)
    for line in open("credentials1.txt", "r").readlines():
        login_info = line.split()
        if username == login_info[0] and password == login_info[1]:
            print("Login credentials are valid!")
            return True
    print("Invalid credentials")
    return False


main()